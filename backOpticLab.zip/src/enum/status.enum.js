const status = {
    active: 'active',
    passive: 'passive'
};

export default status;
