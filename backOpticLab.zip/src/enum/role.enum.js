const role = {
    admin: 'admin',
    primeminister: 'primeminister',
    parlamentpresident: 'parlamentpresident',
    member: 'member'
};

export default role;
