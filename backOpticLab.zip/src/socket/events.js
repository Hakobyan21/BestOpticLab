export default {
    CLICK: 'click',
    REFRESH: 'REFRESH',
    CONNECTED: 'connected',
    DISCONNECT: 'disconnect',
    DISCONNECTED: 'disconnected'
};
